import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;





public class Main extends JFrame implements ActionListener, MouseListener {

	 JPanel northPanel, centerPanel, southPanel;
	 JTable table;
	 DefaultTableModel dtm;
	 JScrollPane sp;
	 JLabel lblId,lblInvoicenumber,lblCustomername, lblNominal, lblAction, lblTitleSearch,lblTitleSearchcus ,lblSearchinvoice, lblSearchcustomer;
	 JTextField tfSearchinvoice, tfSearchcustomer;
	 JButton btnSearch, btnExit;
	
	
	 Connect con = new Connect();
	 
	 
	public Main() {
		//NORTH
		
		northPanel = new JPanel();
		
		table = new JTable() {
			
		
			
			   @Override
			   public boolean isCellEditable(int row, int column) {
			   return false;
			   }
			   
			  };
				Vector<Object> tableHeader;
				
			    tableHeader = new Vector<>();
				tableHeader.add("ID");
				tableHeader.add("Invoice Number");
				tableHeader.add("Customer Name");
				tableHeader.add("Nominal");
				tableHeader.add("Action");
			  
			  
			  dtm = new DefaultTableModel(tableHeader,0);

			  table.setModel(dtm);
			  //LOAD DATA
			  
			  String query = "SELECT * FROM invoice";
			  ResultSet rs = con.getData(query);
			  
			  try {
				while(rs.next()) {
					  int id = rs.getInt("ID");
					  String number = rs.getString("Invoice Number");
					  String name = rs.getString("Customer Name");
					  String nominal = rs.getString("Nominal");
					  String action = rs.getString("Action");
					
					  Vector<Object> data = new Vector<>();
					  data.add(id);
					  data.add(number);
					  data.add(name);
					  data.add(nominal);
					  data.add(action);
					  
					  dtm.addRow(data);
				  }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
			  
			  sp = new JScrollPane(table);
			  sp.setPreferredSize(new Dimension(800,300));
			  

			  northPanel.add(sp);
		
		//CENTER
			centerPanel = new JPanel(new GridBagLayout());
			
			lblTitleSearch = new JLabel("Search by Invoice :");
			tfSearchinvoice = new JTextField();
			tfSearchinvoice.setPreferredSize(new Dimension(300,25));
			
			lblTitleSearchcus = new JLabel("Search by Customer Name :");
			tfSearchcustomer = new JTextField();
			tfSearchcustomer.setPreferredSize(new Dimension(300,25));
			
			 GridBagConstraints c = new GridBagConstraints();
			  
			   c.insets = new Insets(20,20,20,20);
			  
			   c.anchor = GridBagConstraints.WEST;
			   
			  c.gridx = 0;
			  c.gridy = 0;
			  centerPanel.add(lblTitleSearch, c);
			 
			  c.gridx = 1;
			  centerPanel.add(lblTitleSearchcus, c);
			  
			  c.gridx = 0;
			  c.gridy = 1;
			  centerPanel.add(tfSearchinvoice,c);
			  
			  c.gridx = 1;
			  centerPanel.add(tfSearchcustomer,c);
			 
			
			//SOUTH
			  
			  southPanel = new JPanel();
			  
			  btnSearch = new JButton("SEARCH");
			  btnSearch.setPreferredSize(new Dimension(300,25));
			  btnSearch.addActionListener(this);
			  
			  btnExit = new JButton("EXIT");
			  btnExit.setPreferredSize(new Dimension(300,25));
			  btnExit.addActionListener(this);
			
			 southPanel.add(btnSearch);
			 southPanel.add(btnExit);
			 
		
		
		
		
			  add(northPanel, BorderLayout.NORTH);
			  add(centerPanel, BorderLayout.CENTER);
			  add(southPanel, BorderLayout.SOUTH);
		
		
		
		
		  setTitle("Invoice Application  - CV Nusantara Bina");
		  setSize(800,600);
		  setVisible(true);
		  setLocationRelativeTo(null);
		  setDefaultCloseOperation(EXIT_ON_CLOSE);
		  setResizable(false);
	}

	public static void main(String[] args) {
		new Main();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnSearch) {
			
		}
		
		if(e.getSource() == btnExit) {
			
		}
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
