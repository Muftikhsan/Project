
public class Invoice {

	private int Id;
	public Invoice(int id, String invoiceNumber, String customerName, String nominal, String action) {
		super();
		Id = id;
		this.invoiceNumber = invoiceNumber;
		this.customerName = customerName;
		this.nominal = nominal;
		this.action = action;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getNominal() {
		return nominal;
	}
	public void setNominal(String nominal) {
		this.nominal = nominal;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	private String invoiceNumber, customerName, nominal, action;
}
