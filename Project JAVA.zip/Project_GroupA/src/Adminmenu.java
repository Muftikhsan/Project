import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Adminmenu implements ActionListener {

    JFrame frame;
    JInternalFrame iFrame;
    JMenuBar menuBar;
    JMenu account, manage;
    JMenuItem logout, product, productType;
    
    public Adminmenu() {
        frame = new JFrame("Stophee");
        menuBar = new JMenuBar();
        account = new JMenu("Account");
        manage = new JMenu("Manage");
        logout = new JMenuItem("Log Out");
        logout.addActionListener(this);
        product = new JMenuItem("Product");
        product.addActionListener(this);
        productType = new JMenuItem("Product Type");
        productType.addActionListener(this);
        
        menuBar.add(account);
        menuBar.add(manage);
        
        account.add(logout);
        
        manage.add(product);
        manage.add(productType);

        
        
        frame.setJMenuBar(menuBar);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000,500);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new Adminmenu ();
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == logout) {
			new Login();
			frame.setVisible(true);
			frame.dispose();
		} else if(e.getSource() == product) {
			new Manageproduct();
			frame.setVisible(true);
			frame.dispose();
		} else if(e.getSource() == productType) {
			new Manageproducttype();
			frame.setVisible(true);
			frame.dispose();
		}
		
		
	}

}
