import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;



import java.sql.PreparedStatement;

public class Connect {

	private final String USERNAME = "root"; 
	private final String PASSWORD = ""; 
	private final String DATABASE = "stopee"; 
	private final String CONECTION = String.format("jdbc:mysql://localhost:3306/stopee");
	
	private Connection con;
	private Statement st;
	private static Connect connect;
	ResultSet rs;
	
	public Connect() {
		try {  
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(CONECTION, USERNAME, PASSWORD);  
            st = con.createStatement(); 
        } catch(Exception e) {
        	e.printStackTrace();
        	
        }  
    }
		
	 public ResultSet executeQuery(String query) {
	        ResultSet rs = null;
	    	try {
	            rs = st.executeQuery(query);
	        } catch(Exception e) {
	        	e.printStackTrace();
	        }
	        return rs;
	    }
	

	public static void main(String[] args) {
		new Connect();

	}


	private PreparedStatement preparedStatement(String query) {
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = con.prepareStatement(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return preparedStatement;
	}
	

	 public void executeUpdate(String query) {
	    	try {
				st.executeUpdate(query);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	 public ResultSet selectByUsername(String username) {
			String query = String.format("SELECT * FROM member WHERE Username = '%s' LIMIT 1", username);
			return executeQuery(query);
		}



	public void insertDataUser(User user) {
		String query = "INSERT INTO user(id,name, email, password, phone, gender, role) VALUES(?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = preparedStatement(query);
		try {
			preparedStatement.setInt(1, user.getId());  // query -> index mulai dr 1
			preparedStatement.setString(2, user.getName());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setString(4, user.getPassword());
			preparedStatement.setString(5, user.getPhone());
			preparedStatement.setString(6, user.getGender());
			preparedStatement.setString(7, user.getRole());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public ResultSet selectByUsernameAndPassword(User user) {
		String sql = "SELECT * FROM member WHERE Username = '%s' AND Password = '%s' LIMIT 1";
		String query = String.format(sql, user.getEmail(), user.getPassword());
		return executeQuery(query);
	}

	public ResultSet selectByEmail(String email) {
		String query = String.format("SELECT * FROM user WHERE email = '%s' LIMIT 1", email);
		return executeQuery(query);
	}

	public static synchronized Connect getConnection() {
		/**
		* If the connect is null then:
		*   - Create the instance from Connect class
		*   - Otherwise, just assign the previous instance of this class
		*/
		return connect = (connect == null) ? new Connect() : connect;
    }
	
	 public PreparedStatement prepareStatement(String query) {
	    	PreparedStatement ps = null;
	    	try {
				ps = con.prepareStatement(query);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    	return ps;
	    }
	
	
}
