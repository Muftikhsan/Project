import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Manageproduct extends JFrame implements ActionListener{
 
	JFrame frame;
    JInternalFrame iFrame;
    JMenuBar menuBar;
    JMenu account, manage;
    JMenuItem logout, product, productType;	
 JPanel northPanel, centerPanel, southPanel;
 JTable table;
 DefaultTableModel dtm;
 JScrollPane sp;
 JLabel lblTitle,lblProduct,lblProductname, lblProducttype, lblProductprice, lblProductqty;
 JTextField tfProductname;
 JSpinner srProductprice, srProductqty;
 JComboBox<String> cbProducttype;
 JButton add,update,delete;
 private Vector<Product> products;
 
 Connect con = new Connect();
 
// Vector<Product> getProduct() {
//		Vector<Product> vecProduct = new Vector<>();
//		
//		PreparedStatement ps = Connect.getConnection().prepareStatement("SELECT * FROM product");
//		try {
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()) {
//				int Producttypeid = rs.getInt("id");
//				String Productname = rs.getString("name");
//				String Productprice = rs.getString("price");
//				int Productquantity = rs.getInt("quantity");
//				vecProduct.add(new Product(Producttypeid, Productname, Productprice, Productquantity));
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return vecProduct;
 
 public Manageproduct() {
	 frame = new JFrame("Stophee");
     menuBar = new JMenuBar();
     account = new JMenu("Account");
     manage = new JMenu("Manage");
     logout = new JMenuItem("Log Out");
     logout.addActionListener(this);
     product = new JMenuItem("Product");
     productType = new JMenuItem("Product Type");
     productType.addActionListener(this);
     
     menuBar.add(account);
     menuBar.add(manage);
     
     account.add(logout);
     
     manage.add(product);
     manage.add(productType);
	 
	 
  // NORTH
  northPanel = new JPanel();
  
  
  table = new JTable() {
   @Override
   public boolean isCellEditable(int row, int column) {
   return false;
   }
   
  };
 
  String[] header = {"ProductID", "ProductName", "ProductTypeName", "ProductPrice", "ProductQuantity"};
  Object[][] data = 
      {
        {"1","Chitato" ,"Food", "10000", "5"},
        {"3","Coca Cola" ,"Drinks", "12000", "10"}
      };
  
  dtm = new DefaultTableModel(data, header);
  table.setModel(dtm);
  
  sp = new JScrollPane(table);
  sp.setPreferredSize(new Dimension(400,200));
  

  northPanel.add(sp);
  
  //LOAD DATA
  String query = "SELECT * FROM product";
  ResultSet rs = con.executeQuery(query);
  
  try {
	while(rs.next()) {
		   int id = rs.getInt("ProductID");
		   String name = rs.getString("ProductName");
		   String price = rs.getString("Productprice");
		   int qty = rs.getInt("Productquantity");
		   
		   Vector<Object> dat = new Vector<>();
		   dat.add(id);
		   dat.add(name);
		   dat.add(price);
		   dat.add(qty);
		   
		   dtm.addRow(dat);
  
	 }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  
  // CENTER
  centerPanel = new JPanel(new GridBagLayout());
  
  lblProductname = new JLabel ("Product Name : ");
  tfProductname = new JTextField(15);
  
  lblProducttype = new JLabel ("Product Type : ");
  String type[] = {"Food","Drinks"};
  cbProducttype = new JComboBox<String>(type);
  cbProducttype.setPreferredSize(new Dimension(170,20));
  
  lblProductprice = new JLabel ("Product Price : ");
  srProductprice = new JSpinner();
  srProductprice.setPreferredSize(new Dimension(170,20));
  
  lblProductqty = new JLabel ("Product Quantity : ");
  srProductqty = new JSpinner();
  srProductqty.setPreferredSize(new Dimension(170,20));
  
   GridBagConstraints c = new GridBagConstraints();
  
   c.insets = new Insets(20,20,20,20);
  
   c.anchor = GridBagConstraints.WEST;
   
  c.gridx = 0;
  c.gridy = 0;
  centerPanel.add(lblProductname, c);
 
  c.gridx = 1;
  centerPanel.add(tfProductname, c);
 
  c.gridx = 0;
  c.gridy = 1;
  centerPanel.add(lblProducttype,c);
  
  c.gridx = 1;
  centerPanel.add(cbProducttype,c);
  
  c.gridx = 0;
  c.gridy = 2;
  centerPanel.add(lblProductprice,c);
  
  c.gridx = 1;
  centerPanel.add(srProductprice,c);
  
  c.gridx = 0;
  c.gridy = 3;
  centerPanel.add(lblProductqty,c);
  
  c.gridx = 1;
  centerPanel.add(srProductqty,c);
  
  
  
  // SOUTH
  southPanel = new JPanel();
  
  add = new JButton("Add");
  add.addActionListener(this);
  
  update = new JButton("Update");
  update.addActionListener(this);
  
  delete = new JButton("Delete");
  delete.addActionListener(this);
  
  southPanel.add(add);
  southPanel.add(update);
  southPanel.add(delete);
  
  add(northPanel, BorderLayout.NORTH);
  add(centerPanel, BorderLayout.CENTER);
  add(southPanel, BorderLayout.SOUTH);
  
  setTitle("Stophee");
  setJMenuBar(menuBar);
  setSize(800,600);
  setVisible(true);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setResizable(false);
 }



 public static void main(String[] args) {
  new Manageproduct();

 }



 @Override
 public void actionPerformed(ActionEvent e) {
  if (e.getSource() == add) {
	  if(tfProductname.getText().isEmpty()) {
		  JOptionPane.showMessageDialog(null, "Name length must be between 5 and 15");
	  } else if(cbProducttype.getSelectedItem() == null) {
		  JOptionPane.showMessageDialog(null, "Product Type must be chosen");
	  } else {
		  Vector<String> newData = new Vector<>();
			newData.add(tfProductname.getText());
			newData.add((String) cbProducttype.getSelectedItem());
			newData.add((String) srProductprice.getValue());
			newData.add((String) srProductqty.getValue());
			
			System.out.println("ini" + newData);
			dtm.addRow(newData);
			
			JOptionPane.showMessageDialog(null, "Product Added");
	
			tfProductname.setText("");
			cbProducttype.setSelectedItem("");
			srProductprice.setValue("");
			srProductqty.setValue("");
		 
		  
		 
		  
		  
		  
		  
		  
	  }
   
  } 
  if (e.getSource() == update) {
	 
	  
	  
  }
  
  if (e.getSource() == delete) {
	  int row = table.getSelectedRow();
	  
	  if(row < 0) {
		  JOptionPane.showMessageDialog(null, "Choose data to be deleted");
	  } else {
		  dtm.removeRow(row);
		  JOptionPane.showMessageDialog(null, "Delete Success");
	  }
  }
  
  
  if (e.getSource() == productType) {
	  new Manageproducttype();
	  setVisible(true);
	  this.dispose();
	 
	  
  } else if (e.getSource() == logout) {
	  new Login();
	  setVisible(true);
	  this.dispose();
  }
  
 }

 }

