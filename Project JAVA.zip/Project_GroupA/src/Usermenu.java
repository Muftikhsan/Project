import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

public class Usermenu implements ActionListener, MenuListener {

    JFrame frame;
    JInternalFrame iFrame, BuyProduct;
    JMenuBar menuBar;
    JMenu account, buy, transaction;
    JMenuItem logout;

    public Usermenu() {
        frame = new JFrame("Stophee");
        menuBar = new JMenuBar();
        account = new JMenu("Account");
        buy = new JMenu("Buy");
        buy.addMenuListener(this);
  
        transaction = new JMenu("Transaction");
        transaction.addMenuListener(this);
        
        logout = new JMenuItem("Log Out");
        logout.addActionListener(this);
       

        menuBar.add(account);
        menuBar.add(buy);
        menuBar.add(transaction);

        account.add(logout);
       





        frame.setJMenuBar(menuBar);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000,500);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new Usermenu ();
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == logout ) {
			new Login();
			frame.setVisible(true);
			frame.dispose();
		} 
		
	}

	

	@Override
	public void menuCanceled(MenuEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuDeselected(MenuEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuSelected(MenuEvent e) {
		if(e.getSource() == buy) {
			new Buyproduct();
			frame.setVisible(true);
			frame.dispose();
		} else if(e.getSource() == transaction) {
			new Transactionform();
			frame.setVisible(true);
			frame.dispose();
		}
		
	}

}
