import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends JFrame implements ActionListener{

 JPanel titlePanel, contentPanel, buttonPanel,
 usernameLabelPanel, usernameFieldPanel, passwordLabelPanel, passwordFieldPanel,emailpanel,passpanel;
 JLabel titleLabel, usernameLabel, passwordLabel;
 JTextField usernameField;
 JPasswordField passwordField;
 JButton loginButton, createButton;
 
  Connect con = new Connect();
 
 public void initialize() {
  titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
  contentPanel = new JPanel(new GridLayout(2, 2));
  emailpanel = new JPanel ();
  passpanel = new JPanel();
  buttonPanel = new JPanel();
  
  usernameLabelPanel = new JPanel();
  usernameFieldPanel = new JPanel();
  passwordLabelPanel = new JPanel();
  passwordFieldPanel = new JPanel();
  
  titleLabel = new JLabel("Login Form");
  usernameLabel = new JLabel("Email");
  passwordLabel = new JLabel("Password");
  
  usernameField = new JTextField();
  passwordField = new JPasswordField();
  loginButton = new JButton("Login");
  createButton = new JButton("Create Account");
 }

 public void set() {
  titlePanel.add(titleLabel);
  
  usernameField.setPreferredSize(new Dimension(150, 25));
  passwordField.setPreferredSize(new Dimension(150, 25));
  
  usernameLabelPanel.add(usernameLabel);
  usernameFieldPanel.add(usernameField);
  passwordLabelPanel.add(passwordLabel);
  passwordFieldPanel.add(passwordField);
  
  emailpanel.add(usernameLabelPanel);
  emailpanel.add(usernameFieldPanel);
  passpanel.add(passwordLabelPanel);
  passpanel.add(passwordFieldPanel);
  
  contentPanel.add(emailpanel, BorderLayout.CENTER);
  contentPanel.add(passpanel, BorderLayout.CENTER);
  
  
  buttonPanel.add(loginButton);
  buttonPanel.add(createButton);
  
  add(titlePanel, BorderLayout.NORTH);
  add(contentPanel, BorderLayout.CENTER);
  add(buttonPanel, BorderLayout.SOUTH);
  
  loginButton.addActionListener(this);
  createButton.addActionListener(this);
 }
 
 public Login() {
  setSize(400, 200); // set ukuran -> width x height
  setLocationRelativeTo(null); // posisinya bakal ke tengah layar
  setTitle("Login Form"); // set judul
  setDefaultCloseOperation(EXIT_ON_CLOSE); //console otomatis clos klo misalkan jframe kita close
  initialize();
  set();
  setVisible(true);
 }
 
 public static void main(String[] args) {
  new Login();
 }
 

 //@SuppressWarnings("deprecation")
 @Override
 public void actionPerformed(ActionEvent e) {
	 if (e.getSource() == loginButton) {
			User user = new User();
			user.setEmail(usernameField.getText());
			user.setPassword(passwordField.getText());
			ResultSet resultSet = new Connect().selectByUsernameAndPassword(user);
			if (user.getEmail().equals("admin@mail.com") && user.getPassword().equals("123123")) {
				new Adminmenu();
				setVisible(true);					
				this.dispose();
			}else if(user.getEmail().isEmpty() && user.getPassword().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Invalid Username or Password!");
			} else {
				new Usermenu();
				setVisible(true);
				this.dispose();
			}
		}
	 
	 
	 
//  if(e.getSource() == loginButton){
//	  User user = new User();
//	  user.setEmail(usernameField.getText());
//	  user.setPassword(passwordField.getText());
//	  ResultSet rs = new Connect().selectbyUsernameAndPassword(user);
//	  
//		  if(user.getEmail().equals("admin") && user.getPassword().equals("admin")) {
//			  JOptionPane.showMessageDialog(null, "Login successfully" );
//			  new Adminmenu();
//			  setVisible(true);
//			  this.dispose();
//		  } else {
//			  new Usermenu();
//			  setVisible(true);
//			  this.dispose();
//		  }
	 
	
	 
	 
 // }
  if(e.getSource() == createButton) {
	  new Registerform();
	  setVisible(true);
	  this.dispose();
  }
 
  
 

 }

}

