
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

public class Transactionform extends JFrame implements ActionListener, MenuListener, MouseListener{
 JFrame frame;
 JInternalFrame iFrame;
 JMenuBar menuBar;
 JMenu account, buy, transaction;
 JMenuItem logout;
 JPanel northPanel, centerPanel, southPanel;
 JTable table1, table2;
 DefaultTableModel dtm1,dtm2;
 JScrollPane sp1,sp2;
 JLabel lblTitle, lblTitle2, lblTotal;
 JTextField tfTotal;
 JSpinner srProductprice, srProductqty;
 JComboBox<String> cbProducttype;
 JButton check;
 
 public Transactionform() {
	   frame = new JFrame("Stophee");
       menuBar = new JMenuBar();
       account = new JMenu("Account");
       buy = new JMenu("Buy");
       buy.addMenuListener(this);
 
       transaction = new JMenu("Transaction");
       logout = new JMenuItem("Log Out");
       logout.addActionListener(this);
      

       menuBar.add(account);
       menuBar.add(buy);
       menuBar.add(transaction);
       account.add(logout);

	 
	 
	 // NORTH
  northPanel = new JPanel(new GridBagLayout());
  
  lblTitle = new JLabel("Header Transaction");
  
  
  table1 = new JTable() {
   @Override
   public boolean isCellEditable(int row, int column) {
   return false;
   }
   
  };
 
  String[] header = {"TransactionID", "Date of Transaction", "Payment Type"};
  Object[][] data = 
      {
        {"1","2021-05-29" ,"Cash"},
        {"2","2021-05-29" ,"Cash"},
        {"3","2021-05-29" ,"Cash"}
      };
  
  dtm1 = new DefaultTableModel(data, header);
  table1.setModel(dtm1);
  
  sp1 = new JScrollPane(table1);
  sp1.setPreferredSize(new Dimension(700,200));
  table1.addMouseListener(this);

  GridBagConstraints c = new GridBagConstraints();
  
  c.insets = new Insets(20,20,20,20);
 
  c.anchor = GridBagConstraints.WEST;
  
 c.gridx = 0;
 c.gridy = 0;
 northPanel.add(lblTitle, c);

 c.gridy = 1;
 northPanel.add(sp1, c);
  
 
  
  
  
  // CENTER
  centerPanel = new JPanel(new GridBagLayout());
  
  lblTitle2 = new JLabel("Detail Transaction");
  
  table2 = new JTable() {
	   @Override
	   public boolean isCellEditable(int row, int column) {
	   return false;
	   }
	   
	  };
	 
	  String[] head = {"TransactionID", "Product Name", "ProductType", "Quantity"};
	  
	  
	  dtm2 = new DefaultTableModel(head,0);
	  table2.setModel(dtm2);
	  
	  sp2 = new JScrollPane(table2);
	  sp2.setPreferredSize(new Dimension(700,100));
 
   GridBagConstraints b = new GridBagConstraints();
  
   b.insets = new Insets(20,20,20,20);
  
   b.anchor = GridBagConstraints.WEST;
   
  b.gridx = 0;
  b.gridy = 0;
  centerPanel.add(lblTitle2, b);
 
  b.gridy = 1;
  centerPanel.add(sp2, b);
 

  
  
  
  // SOUTH
  southPanel = new JPanel();
  
  lblTotal = new JLabel("Total");
  tfTotal = new JTextField();
  tfTotal.setPreferredSize(new Dimension(50,25));
  
  check = new JButton("Check");
  check.addActionListener(this);
  
  southPanel.add(lblTotal);
  southPanel.add(tfTotal);
  southPanel.add(check);
 
  add(northPanel, BorderLayout.NORTH);
  add(centerPanel, BorderLayout.CENTER);
  add(southPanel, BorderLayout.SOUTH);
  
  setTitle("Stophee");
  setJMenuBar(menuBar);
  setSize(900,700);
  setVisible(true);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setResizable(false);
 }



 public static void main(String[] args) {
  new Transactionform();

 }



 @Override
 public void actionPerformed(ActionEvent e) {
	 if(e.getSource() == logout ) {
			new Login();
			frame.setVisible(true);
			frame.dispose();
		} 
 }



@Override
public void menuCanceled(MenuEvent e) {
	// TODO Auto-generated method stub
	
}



@Override
public void menuDeselected(MenuEvent e) {
	// TODO Auto-generated method stub
	
}



@Override
public void menuSelected(MenuEvent e) {
	if(e.getSource() == buy) {
		new Buyproduct();
		frame.setVisible(true);
		frame.dispose();
	} 
	
}



@Override
public void mouseClicked(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}



@Override
public void mouseEntered(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}



@Override
public void mouseExited(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}



@Override
public void mousePressed(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}



@Override
public void mouseReleased(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

}
