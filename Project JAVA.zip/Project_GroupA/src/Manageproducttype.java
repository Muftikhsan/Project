import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Manageproducttype extends JFrame implements ActionListener{
 
	JFrame frame;
    JInternalFrame iFrame;
    JMenuBar menuBar;
    JMenu account, manage;
    JMenuItem logout, product, productType;	
 JPanel northPanel, centerPanel, southPanel;
 JTable table;
 DefaultTableModel dtm;
 JScrollPane sp;
 JLabel idLabel;
 JTextField idField;
 JButton add,update,delete;
 
 public Manageproducttype() {
	 frame = new JFrame("Stophee");
     menuBar = new JMenuBar();
     account = new JMenu("Account");
     manage = new JMenu("Manage");
     logout = new JMenuItem("Log Out");
     logout.addActionListener(this);
     product = new JMenuItem("Product");
     product.addActionListener(this);
     productType = new JMenuItem("Product Type");
     productType.addActionListener(this);
     
     menuBar.add(account);
     menuBar.add(manage);
     
     account.add(logout);
     
     manage.add(product);
     manage.add(productType);
	 
	 // NORTH
  northPanel = new JPanel();
  
  table = new JTable() {
   @Override
   public boolean isCellEditable(int row, int column) {
   return false;
   }
   
  };
 
  String[] header = {"ProductTypeID", "ProductTypeName"};
  Object[][] data = 
      {
        {"1", "Food"},
        {"2", "Drinks"}
      };
  
  dtm = new DefaultTableModel(data, header);
  table.setModel(dtm);
  
  sp = new JScrollPane(table);
  sp.setPreferredSize(new Dimension(400,200));
  
  northPanel.add(sp);
  
  
  
  // CENTER
  centerPanel = new JPanel(new GridBagLayout());
  
  idLabel = new JLabel ("Type: ");
  
  idField = new JTextField(15);
  
  GridBagConstraints c = new GridBagConstraints();
  
  c.insets = new Insets(10,10,10,10);
  
  
  c.gridx = 0;
  c.gridy = 0;
  centerPanel.add(idLabel, c);
  
  c.gridx = 1;
  centerPanel.add(idField, c);
 
  
  
  // SOUTH
  southPanel = new JPanel();
  
  add = new JButton("Add");
  add.addActionListener(this);
  
  update = new JButton("Update");
  update.addActionListener(this);
  
  delete = new JButton("Delete");
  delete.addActionListener(this);
  
  southPanel.add(add);
  southPanel.add(update);
  southPanel.add(delete);
  
  add(northPanel, BorderLayout.NORTH);
  add(centerPanel, BorderLayout.CENTER);
  add(southPanel, BorderLayout.SOUTH);
  
  setTitle("Stophee");
  setJMenuBar(menuBar);
  setSize(800,400);
  setVisible(true);
  setLocationRelativeTo(null);
  setDefaultCloseOperation(EXIT_ON_CLOSE);
  setResizable(false);
 }



 public static void main(String[] args) {
  new Manageproducttype();

 }



 @Override
 public void actionPerformed(ActionEvent e) {
  if (e.getSource() == add) {
   System.out.println("Add");
   
  }
  if(e.getSource() == product) {
	  new Manageproduct();
	  setVisible(true);
	  this.dispose();
  } else if (e.getSource() == logout) {
	  new Login();
	  setVisible(true);
	  this.dispose();
  }
 }

}

