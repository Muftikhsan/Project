import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.table.DefaultTableModel;

public class Buyproduct implements ActionListener, MenuListener, MouseListener {

    JFrame frame;
    JInternalFrame iFrame;
    JMenuBar menuBar;
    JMenu account, buy, transaction;
    JMenuItem logout;
    JPanel northPanel, centerPanel, southPanel, pnlSelectedData;
    JTable table1, table2;
    DefaultTableModel dtm1, dtm2;
    JScrollPane sp1,sp2;
    JLabel lblQuantity, lblPaymenttype, lblProduct, lblCart, lblSelectedData;
    JSpinner srQuantity;
    JRadioButton rbCash, rbDebitcredit;
    ButtonGroup groupPayment;
    JButton btnAdd, btnchkout;
    
    Connect con = new Connect();

    public Buyproduct() {
        frame = new JFrame("Stophee");
        menuBar = new JMenuBar();
        account = new JMenu("Account");
        buy = new JMenu("Buy");
       
  
        transaction = new JMenu("Transaction");
        transaction.addMenuListener(this);
        
        logout = new JMenuItem("Log Out");
        logout.addActionListener(this);
       

        menuBar.add(account);
        menuBar.add(buy);
        menuBar.add(transaction);
        account.add(logout);
       

        //NORTH
        northPanel = new JPanel(new GridBagLayout());
        
        lblQuantity = new JLabel("Quantity : ");
        srQuantity = new JSpinner();
        srQuantity.setPreferredSize(new Dimension(200,25));
        
        lblPaymenttype = new JLabel("Payment Type : ");
        rbCash = new JRadioButton("Cash");
		rbDebitcredit = new JRadioButton("Debit/Credit");
		groupPayment = new ButtonGroup();
		groupPayment.add(rbCash);
		groupPayment.add(rbDebitcredit);
        
		GridBagConstraints c = new GridBagConstraints();
		  
		   c.insets = new Insets(20,20,20,20);
		   
		   c.gridx = 0;
		   c.gridy = 0;
		  northPanel.add(lblQuantity, c);
		  
		   c.gridx = 1;
		   northPanel.add(srQuantity, c);
		  
		   c.gridx = 0;
		   c.gridy = 1;
		   northPanel.add(lblPaymenttype,c);
		   
		   c.gridx = 1;
		   northPanel.add(rbCash,c);
		   
		   c.gridx = 2;
		   northPanel.add(rbDebitcredit,c);
		
       //LOAD DATA
		   String query = "SELECT * FROM product";
		   ResultSet rs = con.executeQuery(query);
		   
		   try {
			while(rs.next()) {
				   int id = rs.getInt("ProductID");
				   String name = rs.getString("ProductName");
				   String price = rs.getString("Productprice");
				   int qty = rs.getInt("Productquantity");
				   
				   Vector<Object> data = new Vector<>();
				   data.add(id);
				   data.add(name);
				   data.add(price);
				   data.add(qty);
				   
				   dtm1.addRow(data);
				   
				   
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
		   
        // CENTER
        centerPanel = new JPanel(new GridBagLayout());
        
        lblProduct = new JLabel ("Product");
        
       
        
       // centerPanel.add(lblProduct);
        
        
        table1 = new JTable() {
         @Override
         public boolean isCellEditable(int row, int column) {
         return false;
         }
         
        };
       
        String[] header = {"ProductID", "ProductName", "ProductTypeName", "ProductPrice", "ProductQuantity"};
        Object[][] data = 
            {
              {"1","Chitato" ,"Food", "10000", "5"},
              {"3","Coca Cola" ,"Drinks", "12000", "10"}
            };
        
        dtm1 = new DefaultTableModel(data, header);
        table1.setModel(dtm1);
        table1.addMouseListener(this);
        
        sp1 = new JScrollPane(table1);
        sp1.setPreferredSize(new Dimension(400,200));
        
        

       // centerPanel.add(sp1);
           
        lblCart = new JLabel ("Cart");
     //   centerPanel.add(lblCart);
       
        table2 = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
            return false;
            }
            
           };
          
           String[] head = {"ProductID", "ProductName", "ProductTypeName", "ProductPrice", "ProductQuantity"};
         
           
           dtm2 = new DefaultTableModel(head,0);
           table2.setModel(dtm2);
           
           sp2 = new JScrollPane(table2);
           sp2.setPreferredSize(new Dimension(400,200));
           

//           centerPanel.add(sp2);
        
           GridBagConstraints b = new GridBagConstraints();
           
           b.insets = new Insets(20,20,20,20);
          
           b.anchor = GridBagConstraints.WEST;
           
          b.gridx = 0;
          b.gridy = 0;
          centerPanel.add(lblProduct, b);
         
          b.gridy = 1;
          centerPanel.add(sp1, b);
         
          b.gridx = 0;
          b.gridy = 1;
          centerPanel.add(lblCart,b);
          
          b.gridx = 1;
          centerPanel.add(sp2,b);
           
           
           //SOUTH
           southPanel = new JPanel();
           
           btnAdd = new JButton ("Add to Cart");
           btnAdd.addActionListener(this);
           btnchkout = new JButton ("Check Out");
           btnchkout.addActionListener(this);
           
           southPanel.add(btnAdd);
           southPanel.add(btnchkout);
           
        frame.add(northPanel, BorderLayout.NORTH);
        frame.add(centerPanel, BorderLayout.CENTER);
        frame.add(southPanel, BorderLayout.SOUTH);




        frame.setJMenuBar(menuBar);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000,700);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new Buyproduct ();
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnAdd) {
			if(groupPayment.getSelection() == null) {
				JOptionPane.showMessageDialog(null, "Payment type must be chosen");
			}
		}else if(e.getSource() == btnchkout) {
			if(groupPayment.getSelection() == null) {
				JOptionPane.showMessageDialog(null, "Payment type must be chosen");
			}else {
				String[] options = {"Yes", "No", "Cancel"};
				int x = JOptionPane.showOptionDialog(null,"Are you sure want to check out?" , "Select an option", JOptionPane.DEFAULT_OPTION,
						JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
				if(x != -1) {
					JOptionPane.showMessageDialog(null, "Transaction Completed");
				}
		}  
		}
		
		if(e.getSource() == logout ) {
			new Login();
			frame.setVisible(true);
			frame.dispose();
		} 

		
		
	}

	@Override
	public void menuCanceled(MenuEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuDeselected(MenuEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuSelected(MenuEvent e) {
		if(e.getSource() == transaction) {
			new Transactionform();
			frame.setVisible(true);
			frame.dispose();
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == table1) {
			String Productid = table1.getValueAt(table1.getSelectedRow(), 0).toString();
			String Productname = table1.getValueAt(table1.getSelectedRow(), 1).toString();
			String Productprice = table1.getValueAt(table1.getSelectedRow(), 2).toString();
			String Productquantity = table1.getValueAt(table1.getSelectedRow(), 3).toString();
			
			//dtm2
			
			
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}