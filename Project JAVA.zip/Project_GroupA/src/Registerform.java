import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.mysql.cj.callback.UsernameCallback;

public class Registerform implements ActionListener{

	JFrame frame;
	JPanel pnlTitle, pnlNama, pnlEmail, pnlPassword, pnlPhone,pnlGender,pnlRadio, pnlRegister;
	JLabel lblTitle, lblNama, lblEmail, lblPassword, lblPhone, lblGender, lblRegister;
	JTextField tfNama, tfEmail, tfPhone;
	JPasswordField pfPassword;
	JRadioButton rbMale, rbFemale;
	ButtonGroup groupGender;
	JButton btnRegister;
	
	Connect con = new Connect();
	
	public Registerform() {
		frame = new JFrame("Stophee");
		pnlTitle = new JPanel();
		pnlNama = new JPanel();
		pnlEmail = new JPanel();
		pnlPassword = new JPanel();
		pnlPhone = new JPanel();
		pnlGender = new JPanel();
		pnlRadio = new JPanel();
		pnlRegister = new JPanel();
		
		
		lblTitle = new JLabel("REGISTER");
		
		lblNama = new JLabel("Name :");
		lblNama.setHorizontalAlignment(JLabel.CENTER);
		tfNama = new JTextField();
		
		lblEmail = new JLabel("Email :");
		lblEmail.setHorizontalAlignment(JLabel.CENTER);
		tfEmail = new JTextField();
		
		lblPassword = new JLabel("Password :");
		lblPassword.setHorizontalAlignment(JLabel.CENTER);
		pfPassword = new JPasswordField();
		
		lblPhone = new JLabel("Phone Number :");
		lblPhone.setHorizontalAlignment(JLabel.CENTER);
		tfPhone = new JTextField();
			
		lblGender = new JLabel("Gender");
		lblGender.setHorizontalAlignment(JLabel.CENTER);
		rbMale = new JRadioButton("Male");
		rbFemale = new JRadioButton("Female");
		groupGender = new ButtonGroup();
		groupGender.add(rbMale);
		groupGender.add(rbFemale);
		
		btnRegister = new JButton("Submit");
		btnRegister.addActionListener(this);
		
//SET LAYOUT		
		frame.setLayout(new GridLayout(7,1,10,10));
		pnlNama.setLayout(new GridLayout(1,2));
		pnlEmail.setLayout(new GridLayout(1,2));
		pnlPassword.setLayout(new GridLayout(1,2));
		pnlPhone.setLayout(new GridLayout(1,2));
		pnlGender.setLayout(new GridLayout(1,2));
		pnlRadio.setLayout(new GridLayout(1,2));
	
		
		
//SET COMPONENT		
		pnlTitle.add(lblTitle);
		pnlNama.add(lblNama);
		pnlNama.add(tfNama);
		pnlEmail.add(lblEmail);
		pnlEmail.add(tfEmail);
		pnlPassword.add(lblPassword);
		pnlPassword.add(pfPassword);
		pnlPhone.add(lblPhone);
		pnlPhone.add(tfPhone);
		pnlRadio.add(rbMale);
		pnlRadio.add(rbFemale);
		pnlGender.add(lblGender);
		pnlGender.add(pnlRadio);
		pnlRegister.add(btnRegister);
		
//SET CONTAINER		
		frame.add(pnlTitle);
		frame.add(pnlNama);
		frame.add(pnlEmail);
		frame.add(pnlPassword);
		frame.add(pnlPhone);
		frame.add(pnlGender);
		frame.add(pnlRegister);
		
		
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setSize(500, 700);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		
	}

	public static void main(String[] args) {
		new Registerform();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnRegister) {
			if(tfNama.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Name length must be between 3 - 30");
			} else if (tfEmail.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Email must be fill");
			}else if(!tfEmail.getText().endsWith(".com")) {
				JOptionPane.showMessageDialog(null, "Email must contain @ and ends with .com");
			} else if (tfPhone.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Phone can't empty & Numeric");
			} else if(pfPassword.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "Password must be fill");
			} else if(groupGender.getSelection() == null) {
				JOptionPane.showMessageDialog(null, "Gender must be chosen");
			}else {
				ResultSet rs = new Connect().selectByUsername(tfEmail.getText());
						JOptionPane.showMessageDialog(null, "Account Created");
						doInsertDataUser();
						new Login();
						frame.setVisible(true);		
						frame.dispose();
					}
				
				
				
				
//				JOptionPane.showMessageDialog(null, "Account created");
//				new Login();
//				frame.setVisible(true);
//				frame.dispose();
			}
			
			
			
		}
		
	

	void doInsertDataUser() {
		User user = new User();
		user.setName(tfNama.getText());
		user.setEmail(tfEmail.getText());
		user.setPassword(pfPassword.getText());
		user.setPhone(tfPhone.getText());
		user.setGender(groupGender.getSelection().getActionCommand());
		new Connect().insertDataUser(user);
	}
	
}
