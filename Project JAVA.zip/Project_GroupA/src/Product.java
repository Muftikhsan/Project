
public class Product {

	private int Producttypeid, Productquantity;
	public Product(int producttypeid, int productquantity, String productname, String productprice) {
		super();
		Producttypeid = producttypeid;
		Productquantity = productquantity;
		Productname = productname;
		Productprice = productprice;
	}
	public int getProducttypeid() {
		return Producttypeid;
	}
	public void setProducttypeid(int producttypeid) {
		Producttypeid = producttypeid;
	}
	public int getProductquantity() {
		return Productquantity;
	}
	public void setProductquantity(int productquantity) {
		Productquantity = productquantity;
	}
	public String getProductname() {
		return Productname;
	}
	public void setProductname(String productname) {
		Productname = productname;
	}
	public String getProductprice() {
		return Productprice;
	}
	public void setProductprice(String productprice) {
		Productprice = productprice;
	}
	private String Productname, Productprice;
}
